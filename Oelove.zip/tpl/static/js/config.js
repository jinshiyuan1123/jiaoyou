var langList = 
[
	{name:'en',	charset:'gb2312'},
	{name:'zh-cn',	charset:'gb2312'},
	{name:'zh-tw',	charset:'gb2312'}
];

var skinList = 
[
	{name:'default',	charset:'gb2312'},
	{name:'whyGreen',	charset:'gb2312'}
];