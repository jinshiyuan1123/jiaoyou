<?php
if(!defined('IN_OESOFT')) {
	exit('Access Denied');
}
$db_host = DB_HOST;
$db_user = DB_USER;
$db_pw = DB_PASS;
$db_name = DB_DATA;
$db_pconnect = 0;
$db_charset = DB_CHARSET;