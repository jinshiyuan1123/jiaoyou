<?php
/**
 * @CopyRight  (C)2010-2012 OEdev.Net Inc.
 * @WebSite    www.phpcoo.com,www.oedev.net
 * @Author     OEdev <phpcoo@qq.com>
 * @Brief      OElove v3.X
**/
///数据库类型
define('DB_TYPE','mysql');
///数据库编码
define('DB_CHARSET','utf8');
///数据库服务器
define('DB_HOST','localhost:3306');
///数据库名
define('DB_DATA','oelovex_v30_standard_db');
///数据库登录帐号
define('DB_USER','root');
///数据库登录密码
define('DB_PASS','root');
///数据表前缀
define('DB_PREFIX','oelovex_');
///数据库持久连接 0=关闭, 1=打开
define('DB_PCONNECT',0);
?>