<?php
/**
 * [OElove] (C)2012-2099 OEdev,Inc.
 * <E-Mail:phpcoo@qq.com>
 * Url www.phpcoo.com, www.oephp.com
 * Update 2014.12.16
 */
define('OESOFT_SOFTNAME', 'OElove');
define('OESOFT_TYPE', 'Free');
define('OESOFT_VERSION', 'v3.5');
define('OESOFT_RELEASE', ".R41216");
define('OESOFT_LICENCE', 'http://www.phpcoo.com/serial/');
define('OESOFT_URL', 'http://www.phpcoo.com/');
define('OESOFT_AUTHOR', 'OEdev');
?>