<?php
/**
 * @CopyRight  (C)2010-2012 OEdev.Net Inc.
 * @WebSite    www.phpcoo.com,www.oedev.net
 * @Author     OEdev <phpcoo@qq.com>
 * @Brief      OElove v3.X
**/
///设置Jbox  可选 artbox/jdbox
define('JBOX', 'jdbox');
?>