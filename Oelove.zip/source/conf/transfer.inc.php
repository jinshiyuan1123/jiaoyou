<?php
/**
 * @Brief 金币、积分转换配置文件
**/
return array (
    ///积分转换金币 状态
	'trade_money'=>false,
	///积分转换金币 比例
	'trade_money_ratio'=>100,
	///金币转换积分 状态
	'trade_points'=>false,
	///金币转换积分 比例
	'trade_points_ratio'=>500,
);
?>