<?php
define('OEMAIL_FLAG', true);
define('OEMAIL_SMTP', 'smtp.163.com');
define('OEMAIL_PORT', 25);
define('OEMAIL_SENDER', 'MAIL测试');
define('OEMAIL_EMAIL', 'testmail033@163.com');
define('OEMAIL_PASSWORD', 'love1314');
define('OEMAIL_TYPE', 1);
?>