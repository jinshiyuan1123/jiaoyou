<?php
define('OE_VERSION', 'v3.5');
define('OE_EDITION', 'Free')
?>